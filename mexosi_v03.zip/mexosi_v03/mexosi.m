function mexosi
% Solve a linear and quadratic, mixed integer, programming problem
% usage: [x,y,status] = 
%  mexosi(n_vars,n_cons,A,x_lb,x_ub,c,Ax_lb,Ax_ub,isMIP,isQP,isinteger,Q,options)
