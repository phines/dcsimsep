MEX OSI is a poorly written MATLAB interface to the OSI/Clp/Cbc code from the COIN-OR project.

Poorly written by Paul Hines, University of Vermont, 2009

To build the code on a unix-like machine travel to the mexosi directory and type make within matlab.  This should build Cbc.  Look at testosi.m for an expaple.


